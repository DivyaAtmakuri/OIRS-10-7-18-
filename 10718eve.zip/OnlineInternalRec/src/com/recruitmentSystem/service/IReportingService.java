package com.recruitmentSystem.service;

public interface IReportingService {

}
